# Raw HTTP Notes API

## 1. Project Overview

The **Raw HTTP Notes API** is a simple REST API application developed using Python's built-in `http.server` module.

The main purpose of this project is to understand how an HTTP server works internally without using any backend frameworks such as Django, Flask, or FastAPI.

This application allows users to:
- Retrieve all notes.
- Retrieve a specific note using its ID.
- Create a new note.
- Delete an existing note.
- Handle invalid requests and HTTP errors.

The project also includes custom request logging to display the HTTP method, request path, response status code, and request processing time in the terminal.

## 2. Technologies Used

- **Python:** Main programming language.
- **http.server:** Python's built-in module for creating an HTTP server.
- **json:** Used to handle JSON request and response data.
- **time:** Used to calculate request processing time.
- **Postman:** Used to test API endpoints.

## 3. Project Folder Structure
q1_build_a_raw/
│
├── server.py
│
├── README.md
│
├── note.txt
│
└── screenshots/
    ├── 01_terminal_logs.png
    ├── 02_get_all_notes.png
    ├── 03_get_single_note.png
    ├── 04_get_note_not_found.png
    ├── 05_post_create_note.png
    ├── 06_invalid_json.png
    ├── 07_delete_note.png
    └── 08_put_method_not_allowed.png

**File Description:**

- `server.py`: Contains the complete Python HTTP server and API implementation.
- `README.md`: Contains project documentation and instructions.
- `note.txt`: Personal learning and revision notes.
- `screenshots/`: Contains screenshots of terminal output and Postman testing.

## 4. How to Create the Project

Follow these steps to create the project from scratch.

### Step 1: Create the Project Folder

Create a new folder named:
q1_build_a_raw

### Step 2: Open the Project in VS Code

Open VS Code.

Select:

File → Open Folder → Select `q1_build_a_raw`

### Step 3: Create the Python File

Inside the project folder, create a new file named:
server.py

Write the Python HTTP server implementation inside this file.

### Step 4: Create the README File

Create another file named:
README.md

Add the project documentation.

### Step 5: Create the Screenshots Folder

Create a folder named:

screenshots

Save all Postman and terminal screenshots inside this folder.

## 5. Requirements

### Software Requirements

- Python 3.x
- Visual Studio Code (or another Python code editor)
- Postman
- Windows, Linux, or macOS

### Python Modules

This project uses Python's built-in modules:

```python
from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import time
```

No external Python packages are required.

Therefore, you do not need to install any additional packages using pip.

## 6. How to Run the Project

Follow these instructions to run the application.

### Step 1: Open the Terminal

Open the project folder in VS Code.

Select:

Terminal → New Terminal

Make sure the terminal is inside the project directory.

### Step 2: Run the Server

Execute the following command:

```bash
python server.py
```

### Step 3: Server Output

After successfully starting the server, the terminal displays:
Notes API server running at http://localhost:8080

This means the HTTP server is running successfully.

### Step 4: Open Postman

Open Postman and use the following base URL:

```text
http://localhost:8080
```

Now you can test the different API endpoints.

**Important:** Keep the terminal running while testing requests in Postman.

## 7. API Endpoints

The application supports the following HTTP methods:

| HTTP Method | Endpoint | Description |
|---|---|---|
| GET | `/notes` | Retrieve all notes |
| GET | `/notes/{id}` | Retrieve a specific note |
| POST | `/notes` | Create a new note |
| DELETE | `/notes/{id}` | Delete a specific note |
| PUT | `/notes` | Unsupported method; returns 405 |

### 1. GET – Retrieve All Notes

**URL:**
http://localhost:8080/notes

**Method:** GET

This endpoint retrieves all available notes.

### 2. GET – Retrieve a Single Note

**URL:**
http://localhost:8080/notes/2

**Method:** GET

This endpoint retrieves a specific note using its ID.

### 3. POST – Create a New Note

**URL:**
http://localhost:8080/notes

**Method:** POST

**Request Body:**

Select Body → Raw → JSON in Postman.

```json
{
    "text": "Today I learned about HTTP servers."
}
```

This endpoint accepts JSON data and creates a new note.

### 4. DELETE – Delete a Note

**URL:**
http://localhost:8080/notes/2

**Method:** DELETE

This endpoint deletes the note with the specified ID.

### 5. PUT – Method Not Allowed

**URL:**
http://localhost:8080/notes

**Method:** PUT

The application does not support the PUT method.

Therefore, the server returns:

405 Method Not Allowed

## 8. HTTP Status Codes

The application handles different HTTP response status codes.

| Status Code | Meaning | Description |
|---|---|---|
| 200 | OK | Request completed successfully |
| 201 | Created | A new note was successfully created |
| 204 | No Content | Note deleted successfully; response has no body |
| 400 | Bad Request | Invalid JSON or invalid request data |
| 404 | Not Found | Requested note does not exist |
| 405 | Method Not Allowed | HTTP method is not supported |

## 9. Error Handling

The application handles different types of errors.

### Invalid JSON

When the user sends incorrectly formatted JSON data, the server returns:

400 Bad Request

### Note Not Found

When the requested note ID does not exist, the server returns:
404 Not Found

### Unsupported HTTP Method

When the user sends an unsupported HTTP method, such as PUT, the server returns:
405 Method Not Allowed

## 10. Custom Request Logging

The project includes custom logging to monitor incoming HTTP requests.

The logging system records:

- HTTP request method.
- Request URL/path.
- HTTP response status code.
- Request processing time.

The `time.perf_counter()` function is used to calculate the time taken to process a request.

The `send_response()` method is wrapped to capture the HTTP response status code.

The `finally` block ensures that the logging code executes after request handling, including when an exception occurs.

### Example Terminal Output

127.0.0.1 - - [20/Nov/2026 10:30:00] "GET /notes HTTP/1.1" 200 -

GET /notes 200 0.0042 seconds

This output shows that the GET request was successfully processed with status code 200.

## 11. Postman Testing

The API endpoints were tested using Postman.

The following test cases were performed:

| No. | Test Case | Expected Status |
|---|---|---|
| 1 | GET all notes | 200 OK |
| 2 | GET a single note (ID 2) | 200 OK |
| 3 | GET a non-existing note (ID 99) | 404 Not Found |
| 4 | POST a valid note | 201 Created |
| 5 | POST invalid JSON | 400 Bad Request |
| 6 | DELETE an existing note | 204 No Content |
| 7 | PUT request | 405 Method Not Allowed |

### Screenshots

All testing screenshots are stored in the `screenshots` folder.

The screenshots include:
- Terminal request logs.
- GET all notes.
- GET a single note.
- GET note not found.
- POST a new note.
- Invalid JSON response.
- DELETE a note.
- PUT method not allowed.

## 12. Learning Outcomes

Through this project, I learned:

1. How to create a basic HTTP server using Python.
2. How HTTP requests and responses work.
3. How to handle GET, POST, and DELETE requests.
4. How to read and process JSON request data.
5. How to return appropriate HTTP status codes.
6. How to handle invalid requests and errors.
7. How to implement custom request logging.
8. How to calculate request processing time.
9. How to test API endpoints using Postman.

## 13. Conclusion

This project helped me understand the fundamentals of HTTP server development using Python's built-in `http.server` module.

Instead of depending on a backend framework, I implemented the basic API functionality using Python's standard library.

It improved my understanding of HTTP methods, JSON handling, response status codes, error handling, and request logging.

**Project Name:** Raw HTTP Notes API

**Language:** Python

**Testing Tool:** Postman