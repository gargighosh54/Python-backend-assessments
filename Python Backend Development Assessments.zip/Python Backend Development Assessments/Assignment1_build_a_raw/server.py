
from http.server import HTTPServer, BaseHTTPRequestHandler
#HTTPServer creates the own server , 
# BaseHTTPRequestHandler handles incoming HTTP requests, such as GET , POST ,DELETE
import json
#This module converts Python data into JSON and JSON into Python data , API use json data
import time
#Calculates request execution time
from urllib.parse import urlparse
#Separates URL path from query parameters


# In-memory notes storage , dummy records
#These notes are stored in memory, not in a database. When I stop the server, the data will disappear
notes :list = [
    {"id": 1, "text": "Learn Python"},
    {"id": 2, "text": "Learn Django"},
    {"id": 3, "text": "Learn FastAPI"}
]


# Handler class -> tis class handels HTTP requests , NotesHandler inherits from  BaseHTTPRequestHandler
class NotesHandler(BaseHTTPRequestHandler):

    # Send JSON response
    def send_json(self, status, data):
        response = json.dumps(data).encode("utf-8")
        #json.dumps() converts Python data into a JSON string
        #encode("utf-8") converts that string into bytes , Because the HTTP response body is written using a byte stream

        self.send_response(status)
        #This sends the HTTP status code ,ex- self.send_response(200) (successfull)
        self.send_header("Content-Type", "application/json")
        #This tells the client that our response contains JSON data
        self.send_header("Content-Length", str(len(response)))
        #This tells the client how many bytes are present in the response body
        self.end_headers()
        #This tells the server that we have finished sending response headers
        self.wfile.write(response)
        #This sends the actual response body to the client

    # GET method
    def do_GET(self):
        path = urlparse(self.path).path
        #It extracts the URL path
        # Get all notes
        if path == "/notes":
            self.send_json(200, notes)

        # Get particular note
        elif path.startswith("/notes/"):
            try:
                note_id = int(path.split("/")[-1])
                #path.split("/") -> splits the URL [-1] means the last element suppose we get "2". then it convert to 2 by int
                note = next((n for n in notes if n["id"] == note_id),None)
                #for n in notes means iterate through the list 
                # n["id"] == note_id checks whether the note ID matches    
                # next() returns the first matching note  
                # None is returned if no matching note exists
                if note:
                    self.send_json(200, note)
                else:
                    self.send_json(404, {"error": f"Note {note_id} not found"})

            except ValueError:
                self.send_json(400, {"error": "Invalid note ID"})
        else:
            self.send_json(404, {"error": "Endpoint not found"})

    # POST method
    def do_POST(self):

        if self.path != "/notes":
            self.send_json(404, {"error": "Endpoint not found"})
            return
        
        try:
            # Read incoming JSON data
            content_length = int(self.headers.get("Content-Length", 0))
            #Content-Length tells us how many bytes are in the request body

            if content_length <= 0:
                raise ValueError("Empty request body")
            body = self.rfile.read(content_length)
            #This reads the JSON data sent by Postman 
            # self.rfile reads incoming request data  
            # self.wfile sends outgoing response data

            # Convert JSON into Python dictionary
            data = json.loads(body.decode("utf-8"))

            # Validate input ,check whether the received JSON is a dictionary
            if not isinstance(data, dict):
                raise ValueError("JSON must be an object")
            text = data.get("text")

            if not isinstance(text, str) or not text.strip():
                self.send_json(400, {"error": "Text is required"})
                return

            # Generate new ID
            new_id = max((note["id"] for note in notes),default=0) + 1

            # Create new note
            new_note :dict = {"id": new_id,"text": text.strip()}

            # Store note
            notes.append(new_note)
            self.send_json(201, new_note)
        except (ValueError, UnicodeDecodeError, json.JSONDecodeError):
            self.send_json(400, {"error": "Invalid JSON or request body"})

    # DELETE method
    def do_DELETE(self):

        path = urlparse(self.path).path
        if not path.startswith("/notes/"):
            self.send_json(404, {"error": "Endpoint not found"})
            return

        try:
            note_id = int(path.split("/")[-1])
            for note in notes:
                if note["id"] == note_id:
                    notes.remove(note)
                    self.send_response(204)  #here i didnot use send_json() because HTTP 204 means No Content
                    self.end_headers()
                    return

            self.send_json(404, {"error": f"Note {note_id} not found"})

        except ValueError:
            self.send_json(400, {"error": "Invalid note ID"})

    # Handle unsupported HTTP methods
    def method_not_allowed(self):
        self.send_json(405, {"error": "Method not allowed"})

    def do_PUT(self):
        self.method_not_allowed()

    def do_PATCH(self):
        self.method_not_allowed()

    def do_OPTIONS(self):
        self.method_not_allowed()

    # Request logging  ,This function is responsible for logging every HTTP request with its method, URL path, status code, and execution time.
    def handle_one_request(self):

        start_time = time.perf_counter()
        #Records the starting time  , time.perf_counter() gives us a high-resolution timer that helps calculate how much time a request takes to execute

        self.status_code = "-"
        #we need to record which status code our server returns
        #But at the beginning of request processing, we don't know which status code will be returned so -> "-" placeholder

        original_send_response = self.send_response
        #In BaseHTTPRequestHandler, Python provides a method called
        #ex- self.send_response(201) - It sends the HTTP status code to the client means created
        #We are storing the original send_response() method in another variable name - original_send_response

        #Why ->Because we want to modify its behaviour slightly.
        #We want to capture the status code whenever our program sends a response.
        #But we also want to preserve the original functionality.
        #This technique is called method wrapping


        #Create logged_send_response()
        def logged_send_response(code, message=None):
            self.status_code = code  #This stores the status code
            original_send_response(code, message)

        self.send_response = logged_send_response
        #This line connects everything
        #self.send_response -> refers to Python's original method
        #So, during this request, whenever our code calls -> python executes - logged_send_response(200) , Instead of directly calling the original method

        try:
            super().handle_one_request() #super() allows us to call the parent class's implementation

        finally:
            self.send_response = original_send_response
            #It restores the original method after processing the request
            elapsed = time.perf_counter() - start_time

            if hasattr(self, "command") and self.command:
                print(
                    f"{self.command} {self.path} "
                    f"{self.status_code} {elapsed:.4f} seconds"
                )
#{elapsed:.4f} -> It formats a floating-point number to four decimal places , elapsed = 0.123456

# Create server
server = HTTPServer(("localhost", 8080), NotesHandler)
print("Notes API server running at http://localhost:8080")

# Start server
server.serve_forever()