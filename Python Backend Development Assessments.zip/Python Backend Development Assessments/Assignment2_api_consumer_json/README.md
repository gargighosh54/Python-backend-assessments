# API Consumer & JSON Report Generator

## 1. Project Overview

The **API Consumer & JSON Report Generator** is a Python-based project that retrieves data from a public REST API, processes the JSON responses, performs data analysis, and generates a structured JSON report.

The project uses the JSONPlaceholder API to retrieve users, posts, and comments. It then analyzes the collected data to calculate statistics such as the number of posts per user, the user whose posts received the most comments, and the average post length.

The final results are saved in a file named `report.json`.

## 2. Objectives

The main objectives of this project are:

- Consume data from external REST API endpoints.
- Send HTTP GET requests using Python Requests.
- Retrieve and process JSON responses.
- Display HTTP status codes, response times, and Content-Type.
- Perform calculations using the retrieved data.
- Handle API errors using exception handling.
- Generate and save a structured JSON report.

## 3. Technologies Used

| Technology | Purpose |
|---|---|
| Python | Main programming language |
| Requests | Sending HTTP requests to APIs |
| JSON | Processing and generating JSON data |
| Time | Measuring API response time |
| JSONPlaceholder | Public REST API used as the data source |

## 4. API Details

**Base URL:**

`https://jsonplaceholder.typicode.com`

The project consumes the following API endpoints:

| Endpoint | HTTP Method | Description |
|---|---|---|
| `/users` | GET | Retrieves all user information |
| `/posts` | GET | Retrieves all posts |
| `/comments` | GET | Retrieves all comments |

### API Data Relationships

- Each user has a unique user ID.
- Each post contains a `userId` that identifies its author.
- Each comment contains a `postId` that identifies the post it belongs to.

These relationships are used to calculate the required statistics.

## 5. Project Folder Structure

q2_api_consumer_json/
│
├── api_client.py
├── report.json
├── README.md
├── requirements.txt
│
└── screenshots/
    └── console_output.png

### File Description

- **api_client.py:** Main Python program that fetches API data, processes it, and generates the report.
- **report.json:** Stores the final calculated results.
- **README.md:** Contains project documentation and execution instructions.
- **requirements.txt:** Contains the required Python dependencies.
- **screenshots/:** Stores screenshots of the program execution.

## 6. Installation and Setup

### Step 1: Install Python

Make sure Python is installed on your system.

Check the Python version:

```bash
python --version
```

### Step 2: Open the Project Folder

Open the project folder in VS Code or a terminal.

```bash
cd q2_api_consumer_json
```

### Step 3: Create a Virtual Environment

```bash
python -m venv myenv
```

### Step 4: Activate the Virtual Environment

For Windows:

```bash
myenv\Scripts\activate
```

### Step 5: Install Dependencies

Install the Requests library:

```bash
pip install requests
```

Alternatively, install all dependencies using:

```bash
pip install -r requirements.txt
```

### requirements.txt
requests

## 7. How to Run the Program

Follow these steps to execute the project:

**Step 1:** Open the project folder in VS Code or Command Prompt.

**Step 2:** Activate the virtual environment.

```bash
myenv\Scripts\activate
```

**Step 3:** Install the required dependencies if they are not already installed.

```bash
pip install -r requirements.txt
```

**Step 4:** Run the Python program.

```bash
python api_client.py
```

**Step 5:** The program automatically sends GET requests to the three API endpoints:

- `/users`
- `/posts`
- `/comments`

**Step 6:** The program receives the JSON responses and processes the data.

**Step 7:** It calculates the required statistics and displays the report summary in the terminal.

**Step 8:** Finally, it generates and saves the output in `report.json` in the project directory.

---

## 8. Complete Program Execution Process

The program follows the execution process below:

### Step 1: Import Required Libraries

The program imports:

- `requests` to communicate with the REST API.
- `json` to process JSON data and generate the output file.
- `time` to measure API response time.

### Step 2: Define the API Base URL

The base URL is stored in a variable:

```python
BASE_URL = "https://jsonplaceholder.typicode.com"
```

This URL is used to connect to the JSONPlaceholder API.

### Step 3: Fetch API Data

The `fetch_data()` function sends GET requests to the required endpoints.

It uses:

```python
requests.get(url, timeout=10)
```

The function retrieves the response and displays:

- HTTP status code
- Response time
- Content-Type

It then converts the JSON response into Python data using:

```python
response.json()
```

### Step 4: Handle API Errors

The program uses `try-except` blocks to handle different errors, including:

- Timeout errors
- Connection errors
- HTTP errors
- General request errors
- Invalid JSON responses

If an API request fails, the program displays an appropriate error message.

### Step 5: Process the Retrieved Data

The `generate_report()` function fetches data from all three endpoints.

It then processes the returned users, posts, and comments.

### Step 6: Calculate Posts Per User

The program uses the `userId` field from each post to count how many posts each user has created.

### Step 7: Calculate Comments Per Post

The program uses the `postId` field from each comment to count the number of comments received by each post.

### Step 8: Find the User with the Most Comments

The program connects posts with their comments and calculates the total comments received by each user's posts.

It then identifies the user with the highest total comment count.

### Step 9: Calculate Average Post Length

The program calculates the length of each post's body using Python's `len()` function.

It adds all post lengths and divides the total by the number of posts.

### Step 10: Generate the Final Report

All calculated results are stored in a Python dictionary.

### Step 11: Save the JSON Report

The program uses:

```python
json.dump(report, file, indent=2)
```

This converts the Python dictionary into formatted JSON and saves it in `report.json`.

### Step 12: Display the Final Summary

Finally, the program displays the total users, posts, comments, top user, and average post length in the terminal.
## 9. Program Execution Flow Diagram
             START
               |
               v
       Import Python Libraries
               |
               v
       Define API Base URL
               |
               v
       Send GET API Requests
               |
        -------------------
        |        |        |
        v        v        v
      Users    Posts   Comments
        |        |        |
        -------------------
               |
               v
       Receive JSON Responses
               |
               v
       Convert JSON to Python Data
               |
               v
          Error Checking
               |
               v
        Process API Data
               |
               v
       Calculate Statistics
               |
       ---------------------
       |         |         |
       v         v         v
     Posts    Comments   Average
    Per User  Per User   Post Length
       |
       v
       Generate Final Report
               |
               v
        Save report.json
               |
               v
        Display Summary
               |
               v
              END


## 10. Report Calculations

The project generates the following information:

| Report Field | Description |
|---|---|
| Total Users | Total number of users retrieved from the API |
| Total Posts | Total number of posts retrieved from the API |
| Total Comments | Total number of comments retrieved from the API |
| Posts Per User | Number of posts created by each user |
| Top User by Comments | User whose posts received the most comments |
| Average Post Length | Average character count of all post bodies |

**Important:** The top user is determined by the total number of comments received by their posts, not by the number of comments they personally wrote.
## 11. Error Handling

The program includes exception handling to manage common