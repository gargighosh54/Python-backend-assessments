import requests
import json
import time


# API Base URL
BASE_URL = "https://jsonplaceholder.typicode.com"

# Function to fetch API data
def fetch_data(endpoint):
    url = BASE_URL + endpoint
    #Python combines the base URL and endpoint -> https://jsonplaceholder.typicode.com/users

    try:
        # Record starting time
        start_time = time.perf_counter()

        # Send GET request
        response = requests.get(url, timeout=10)
        #requests.get()->Sends an HTTP GET request to the external server
        #URL -> Contains the API endpoint
        #timeout=10 -> Means the request has a timeout limit of 10 seconds
        # response -> Stores the HTTP response received from the server

        # Calculate response time
        response_time = time.perf_counter() - start_time

        # Print request information
        print(f"\nGET {endpoint}")
        print("Status Code:", response.status_code)   #The server returns an HTTP status code
        print(f"Response Time: {response_time:.2f}s")
        # 2f->Means display the number with two digits after the decimal point
        print("Content-Type:",response.headers.get("Content-Type", "Not available"))
        #HTTP headers contain additional information about a request or response

        #It checks whether the HTTP response indicates an unsuccessful status
        response.raise_for_status()

        # Convert JSON response into Python data
        return response.json()

    except requests.exceptions.Timeout:
        print(f"Error: Timeout while fetching {endpoint}")

    except requests.exceptions.ConnectionError:
        print(f"Error: Connection failed for {endpoint}")

    except requests.exceptions.HTTPError as error:
        print(f"HTTP Error: {error}")

    except requests.exceptions.RequestException as error:
        print(f"Request Error: {error}")

    except ValueError:
        print(f"Error: Invalid JSON response from {endpoint}")

    return None


# Main function , processes the data and generates the report
def generate_report():

    print("API CONSUMER & JSON REPORT GENERATOR")
    print("=" * 45)

    # Fetch all three APIs
    users = fetch_data("/users")
    posts = fetch_data("/posts")
    comments = fetch_data("/comments")

    # Validate API responses
    if users is None or posts is None or comments is None:
        print("\nReport generation failed.")
        return

    # Create user ID and name mapping
    user_names :dict = {
        user["id"]: user["name"]
        for user in users
    }

    # Count posts per user
    posts_per_user :dict = {}

    for post in posts:
        user_id = post["userId"]
        posts_per_user[user_id] = (posts_per_user.get(user_id, 0) + 1)

    # Count comments for each post
    comments_per_post :dict = {}

    for comment in comments:
        post_id = comment["postId"]
        comments_per_post[post_id] = (comments_per_post.get(post_id, 0) + 1)

    # Calculate total comments received by each user
    comments_per_user :dict= {}

    for post in posts:
        user_id = post["userId"]
        post_id = post["id"]
        comment_count = comments_per_post.get(post_id, 0)
        comments_per_user[user_id] = (comments_per_user.get(user_id, 0) + comment_count)

    # Find user with the most comments
    top_user_id = max(comments_per_user,key=comments_per_user.get)

    top_user = {
        "name": user_names[top_user_id],
        "total_comments": comments_per_user[top_user_id]
    }

    # Calculate average post length
    total_length = sum(len(post["body"]) for post in posts)

    average_post_length = (total_length / len(posts) if posts else 0)

    # Prepare final report
    report = {
        "total_users": len(users),
        "total_posts": len(posts),
        "total_comments": len(comments),
        "posts_per_user": {
            user_names[user_id]: count
            for user_id, count in posts_per_user.items()
        },

        "top_user_by_comments": top_user,
        "average_post_length": round(average_post_length, 2)
    }

    # Save report into JSON file
    with open("report.json", "w", encoding="utf-8") as file:
        #encoding="utf-8" -> Specifies the character encoding used when writing the file.
        json.dump(report, file, indent=2)
        #- report = Python dictionary.
        #file = Destination JSON file.
        #indent=2 = Makes the JSON readable with two-space indentation.
        #Now your report.json is generated

    print("\n" + "=" * 45)
    print("REPORT SUMMARY")
    print("=" * 45)

    print("Total Users:", len(users))
    print("Total Posts:", len(posts))
    print("Total Comments:", len(comments))

    print(
        "Top user by comments:",
        top_user["name"],
        f"({top_user['total_comments']} comments)"
    )

    print("Average Post Length:", average_post_length)

    print("\nReport saved to report.json")


# Program execution
if __name__ == "__main__":

    generate_report()