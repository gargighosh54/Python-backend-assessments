import json
import os

class Product:
#Represents a single product.

    def __init__(self, product_id, name, price):
        self.product_id:int = product_id
        self.name :str= name
        self.price:float = price

    def to_dict(self):
    #Convert product object into dictionary.
        return {
            "id": self.product_id,
            "name": self.name,
            "price": self.price
        }

class ProductRepository:
#Handles product data stored in a JSON file.

    def __init__(self, filename="products.json"):
        self.filename = filename

        if not os.path.exists(self.filename):
            with open(self.filename, "w") as file:
                json.dump([], file)

    def load_products(self)-> list:
    #Read products from JSON file.
        try:
            with open(self.filename, "r") as file:
                products: list = json.load(file)
                return products

        except (json.JSONDecodeError, OSError):
            return []
        

    def save_products(self, products:list)-> None:
    #Save products into JSON file.
        with open(self.filename, "w") as file:
            json.dump(products, file, indent=4)


    def get_all_products(self)->list:
    #Return all products.
        return self.load_products()

    def get_product_by_id(self, product_id):
    #Find a product using its ID.
        products:list = self.load_products()
        for product  in products:             #product is individal product
            if product["id"] == product_id:
                return product
        return None

    def add_product(self, name, price)-> dict:
    #Add a new product.
        products:list = self.load_products()
        new_id :int= max([product["id"] for product in products],default=0) + 1
        product = Product(new_id, name, price)
        products.append(product.to_dict())
        self.save_products(products)
        return product.to_dict()