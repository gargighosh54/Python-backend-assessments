# Import ProductRepository from the Model
from model import ProductRepository

# Import display functions from the View
from view import display_products, display_product, display_message


class ProductController:
    # Controller handles user commands and connects Model with View.
    def __init__(self, repository: ProductRepository):
        # Receive the ProductRepository object through the constructor.
        self.repository: ProductRepository = repository
        # Store the repository object so we can access Model functions.

    def handle_request(self, command: str) -> None:
        # Receive the user's command and decide which operation to perform.
        if command == "list_products":
            # Check whether the user wants to display all products.

            products: list = self.repository.get_all_products()
            # Call the Model to retrieve all products from the JSON file.
            display_products(products)
            # Pass the product list to the View for displaying.

        elif command == "view_product":
            # Check whether the user wants to view a particular product.

            try:

                product_id: int = int(input("Enter Product ID: "))
                # Take the product ID from the user and convert it into an integer.

                product: dict | None = self.repository.get_product_by_id(product_id)
                # Call the Model to find the product using its ID.
                # It returns a dictionary if found, otherwise None.

                display_product(product)
                # Pass the product information to the View for displaying.

            except ValueError:
                display_message("Invalid Product ID. Please enter a number.")

        elif command == "add_product":
            # Check whether the user wants to add a new product.

            try:
                name: str = input("Enter Product Name: ").strip()
                # Take the product name from the user.
                # strip() removes unnecessary spaces from both ends.

                if not name:
                    # Check whether the product name is empty.

                    display_message("Product name cannot be empty.")
                    # Display an error message through the View.
                    return

                price: float = float(input("Enter Product Price: "))
                # Take the product price and convert it into a float.

                if price <= 0:
                    # Check whether the entered price is zero or negative.

                    display_message("Product price must be greater than zero.")
                    return

                product: dict = self.repository.add_product(name, price)
                # Call the Model to create and save the new product.
                # The Model returns the newly created product as a dictionary.

                display_message(
                    f"Product '{product['name']}' added successfully!"
                )
                # Display the success message through the View.

            except ValueError:
                display_message("Invalid price. Please enter a valid number.")

        else:
            display_message("Invalid command. Please try again.")
            # Display an error message through the View.