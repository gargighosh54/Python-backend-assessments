from datetime import datetime
from model import ProductRepository
from controller import ProductController


def middleware(command: str) -> None:
    # Middleware-like function logs every request before the Controller runs.

    current_time: str = datetime.now().strftime("%H:%M:%S")
    # Get the current time in hours, minutes and seconds.

    print(f"\n[LOG] {current_time} {command}")
    # Display the request log with time and user command.

def main():
    repository: ProductRepository = ProductRepository()
    # Create the ProductRepository object.
    # It manages product data stored in the JSON file.

    controller: ProductController = ProductController(repository)
    # Create the Controller object.
    # Pass the repository object to the Controller.

    print("=" * 45)
    print("PRODUCT CATALOGUE APPLICATION")
    print("=" * 45)

    while True:
        print("\nAvailable Commands:")
        print("1. list_products")
        print("2. view_product")
        print("3. add_product")
        print("4. exit")

        command: str = input("\nEnter your command: ").strip()

        # Convert numeric choices into actual commands
        commands: dict = {
            "1": "list_products",
            "2": "view_product",
            "3": "add_product",
            "4": "exit"
        }

        command = commands.get(command, command)
        # If the user enters 1, it becomes list_products.
        # If the user enters a command name, it remains unchanged.

        if not command:
            print("Please enter a valid command.")
            continue

        middleware(command)
        # Log the request before calling the Controller.

        if command == "exit":
            print("\nThank you for using Product Catalogue!")
            break

        controller.handle_request(command)
        # Send the command to the Controller.
if __name__ == "__main__":
    main()
    