# Mini MVC Application in Pure Python

## 1. Project Overview

The **Mini MVC Application** is a command-line-based Product Management System developed using pure Python.

This project demonstrates the implementation of the Model-View-Controller (MVC) architectural pattern without using any external web framework.

The application allows users to manage product records through a terminal interface. Product information is stored in a JSON file, making it possible to save and retrieve records.

The main objective of this project is to understand how MVC architecture separates application responsibilities into different components.

## 2. Technologies Used

- Python
- JSON
- OS module
- Datetime module
- Python Standard Library

**Note:** This project does not require Django, Flask, or any external database.

## 3. Project Features

The application provides the following features:

1. **List Products:** Display all available products.
2. **View Product:** Search and display a particular product using its ID.
3. **Add Product:** Add a new product to the application.
4. **JSON File Storage:** Store product information in `products.json`.
5. **Input Validation:** Validate user input before processing.
6. **Error Handling:** Handle invalid commands and unavailable product IDs.
7. **Middleware-Style Logging:** Display logging information before the controller processes a command.
8. **Automatic JSON File Creation:** Create the JSON file if it does not already exist.

## 4. Project Folder Structure
q3_mini_mvc_application/
│
├── model.py
├── view.py
├── controller.py
├── app.py
├── products.json
├── README.md

**Note:** The screenshot filenames above are examples. Use the actual filenames of your screenshots.

## 5. Explanation of Project Files

### model.py – Model Layer

The Model is responsible for managing product data and JSON file operations.

Responsibilities:

- Define the Product class.
- Define the ProductRepository class.
- Load product records from `products.json`.
- Save product records to the JSON file.
- Retrieve all products.
- Find a product using its ID.
- Add new products to the repository.
- Create the JSON file if it does not exist.

### view.py – View Layer

The View is responsible for displaying information to the user.

Responsibilities:

- Display the list of products.
- Display individual product details.
- Display success messages.
- Display error messages.

The View handles the presentation of information and does not directly manage the JSON file.

### controller.py – Controller Layer

The Controller connects the Model and View.

Responsibilities:

- Receive commands from the application.
- Process user requests.
- Call the appropriate Model methods.
- Send information to the View for display.
- Validate user input.
- Handle invalid commands and product IDs.

### app.py – Application Entry Point

The `app.py` file starts and manages the application.

Responsibilities:

- Initialize the application.
- Create and use the ProductController.
- Display the available menu options.
- Accept user commands.
- Pass commands to the Controller.
- Manage the application loop.
- Allow the user to exit the application.
- Perform middleware-style logging before controller processing.

### products.json – Data Storage

The `products.json` file stores product records in JSON format.

It is used to preserve product information.

If the file does not exist, the application creates it automatically.

New product records are saved to this file.

## 6. MVC Architecture

MVC stands for:

- **Model:** Manages application data and business-related data operations.
- **View:** Displays information to the user.
- **Controller:** Handles user requests and coordinates the Model and View.

### Application Flow

```text
             USER
               |
               |
         Selects an Option
               |
               v
             app.py
               |
               |
      Middleware-Style Logging
               |
               v
          controller.py
               |
          -------------
          |           |
          v           v
       model.py     view.py
          |           |
          v           |
     products.json    |
          |           |
          v           v
       Product Data / Output
               |
               v
             USER
```

### How MVC Works in This Project

1. The user selects an operation from the terminal menu.
2. The application receives the user's command.
3. Middleware-style logging runs before the controller processes the command.
4. The Controller receives and processes the request.
5. The Controller communicates with the Model when product data is required.
6. The Model reads or updates the `products.json` file.
7. The Controller sends the required information to the View.
8. The View displays the result in the terminal.

## 7. Middleware-Style Logging

This project demonstrates a simple middleware-style logging mechanism.

Before the Controller processes a command, the application performs a logging operation.

This helps demonstrate how an incoming request or command can be monitored before reaching the main application logic.

**Important:** This is a simple Python implementation for learning purposes. It is not middleware provided by a web framework.

## 8. Data Storage Using JSON

The application uses `products.json` to store product information.

JSON stands for JavaScript Object Notation. It is a lightweight format used to store and exchange structured data.

The application uses Python's built-in `json` module to:

- Read product information.
- Convert JSON data into Python objects.
- Convert Python data into JSON format.
- Write updated product information to the file.

When a new product is added, the updated records are saved to `products.json`.

## 9. Input Validation and Error Handling

The application includes validation and error handling to manage incorrect user input.

Examples include:

- Handling invalid menu options.
- Handling incorrect product IDs.
- Handling products that do not exist.
- Validating required product information.
- Displaying appropriate messages for unsuccessful operations.

This helps prevent unexpected application termination.

## 10. How to Run the Application

Follow these steps to execute the project on your computer.

### Step 1: Install Python

Make sure Python is installed on your computer.

Check the Python version using:

```bash
python --version
```

### Step 2: Open the Project Folder

Open the project folder in Visual Studio Code.

Example:
q3_mini_mvc_application

### Step 3: Open the Terminal

In VS Code:

1. Click on **Terminal**.
2. Select **New Terminal**.
3. Make sure the terminal is opened inside the project folder.

### Step 4: Run the Application

Execute the following command:

```bash
python app.py
```

### Step 5: Use the Application

After executing the command, the application menu will appear in the terminal.

Select the appropriate numeric option displayed by the application to perform the required operation.

Available operations include:

- List Products
- View Product
- Add Product
- Exit

Follow the instructions displayed in the terminal to enter product information or view existing records.

### Step 6: Check the JSON File

After adding a product, open `products.json`.

You can verify that the new product information has been saved successfully.

**Note:** If `products.json` does not exist, the application creates it automatically.

## 11. Testing and Screenshots

The following screenshots demonstrate the working of the application.

Add your actual screenshots to the `screenshots` folder and include them here.

### 1. Product List

Shows the available product records.

### 2. View Individual Product

Shows the details of a selected product using its ID.

### 3. Add New Product

Demonstrates adding a new product successfully.

### 4. Updated JSON File

Shows the updated product records stored in `products.json`.

### 5. Input Validation and Error Handling

Demonstrates how the application handles invalid commands or incorrect product information.

### 6. Middleware-Style Logging

Shows the logging information displayed before the Controller processes a command.

## 12. Dependencies

This project uses Python's built-in standard-library modules.

Therefore, no external Python packages are required.

No `requirements.txt` is necessary unless additional third-party packages are introduced.

## 13. Expected Learning Outcomes

After completing this assignment, I learned:

- How to implement MVC architecture using pure Python.
- How to separate Model, View, and Controller responsibilities.
- How to create and use Python classes.
- How to perform file handling using JSON.
- How to add and retrieve product records.
- How to implement input validation.
- How to handle application errors.
- How to implement middleware-style logging.
- How to manage application flow using a controller.

## 14. Conclusion

This project demonstrates how a simple Product Management Application can be developed using pure Python and the MVC architectural pattern.

By separating data management, presentation, and application logic into different files, the project provides a better understanding of structured application development.

It also demonstrates JSON-based data storage, input validation, error handling, and middleware-style logging without depending on an external framework.

**Project Name:** Mini MVC Application in Pure Python  
**Language:** Python  
**Architecture:** Model-View-Controller (MVC)  
**Storage:** JSON File