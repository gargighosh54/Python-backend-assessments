def display_products(products: list) -> None:
    #Display all products in table format

    if not products:
        print("\nNo products available.")
        return

    print("\n")
    print("-" * 45)
    print(f"{'ID':<10}{'Name':<20}{'Price':>10}")
    print("-" * 45)

    for product in products:             #product ->dict Individual product
        print(
            f"{product['id']:<10}"
            f"{product['name']:<20}"
            f"{product['price']:>10.2f}"
        )

    print("-" * 45)


def display_product(product: dict | None) -> None:
#Display a single product.

    if product is None:
        print("\nProduct not found.")
        return

    print("\nProduct Details")
    print("-" * 30)
    print(f"ID    : {product['id']}")
    print(f"Name  : {product['name']}")
    print(f"Price : {product['price']:.2f}")
    print("-" * 30)


def display_message(message: str) -> None:
#Display success or error message.
    print(f"\n{message}")