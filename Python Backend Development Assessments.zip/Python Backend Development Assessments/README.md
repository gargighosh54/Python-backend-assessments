# Python Backend Development Assessments

## About This Repository

Welcome to my Python Backend Development Assessment Repository!

This repository contains three practical backend development assignments completed as part of my Python Backend Development Training.

These assignments demonstrate my understanding of Python programming, HTTP communication, REST APIs, JSON data processing, application architecture, and backend development concepts.

Each assignment is maintained in a separate folder with its source code, documentation, dependencies, and execution screenshots.

---

## Assignments Overview

### 1. Build a Raw HTTP Server (No Framework)

**Description:**

Developed a basic HTTP server using Python's built-in `http.server` module without using any web framework.

The project implements a Notes API that supports HTTP methods and JSON-based communication.

**Key Features:**
- Created a custom HTTP server.
- Implemented GET, POST, and DELETE methods.
- Managed notes using in-memory storage.
- Handled JSON request and response data.
- Implemented HTTP status codes.
- Added custom request logging.
- Tested API endpoints using Postman.

**Technologies:** Python, HTTP, JSON, http.server, Postman.

**Folder:** `Assignment_1`

---

### 2. API Consumer & JSON Report Generator

**Description:**

Developed a Python application that consumes a public REST API, retrieves JSON data, processes the information, and generates a structured JSON report.

**Key Features:**
- Consumed REST API endpoints using Python Requests.
- Retrieved users, posts, and comments data.
- Calculated the number of posts per user.
- Identified the user whose posts received the highest number of comments.
- Calculated average post-body length.
- Handled API errors and connection exceptions.
- Measured API response time.
- Generated a structured `report.json` file.

**Technologies:** Python, Requests, REST API, JSON, Exception Handling.

**Folder:** `Assignment_2`

---

### 3. MVC Application

**Description:**

Developed an application based on the Model-View-Controller (MVC) architectural pattern.

The project demonstrates the separation of application logic, data management, and presentation.

**Key Concepts:**
- Model
- View
- Controller
- Application structure
- Separation of concerns

**Technologies:** Python and the technologies used in the assignment.

**Folder:** `Assignment_3`

---

## Repository Structure

Python Backend Assessment/
│
├── README.md
│
├── Assignment1_build_a_raw/
│   ├── Source Code
│   ├── README.md
│   ├── requirements.txt
│   └── screenshots/
│
├── Assignment2_api_consumer_json/
│   ├── Source Code
│   ├── README.md
│   ├── requirements.txt
│   └── screenshots/
│
└── Assignment3_mini_mvc_application/
    ├── Source Code
    ├── README.md
    ├── requirements.txt
    

## Technologies and Concepts Covered

- Python Programming
- HTTP Server Development
- REST API Integration
- JSON Data Processing
- HTTP Methods and Status Codes
- Exception Handling
- API Testing
- MVC Architecture
- Backend Application Development

## Installation and Execution

Each assignment has its own `README.md` and `requirements.txt` file.

To run an assignment:

1. Clone or download this repository.
2. Navigate to the required assignment folder.
3. Create and activate a virtual environment.
4. Install the required dependencies:

```bash
pip install -r requirements.txt
```

5. Follow the execution instructions provided in that assignment's README.md file.

**Note:** Some assignments may use Python's built-in modules and may not require additional package installation.


## Project Documentation

Each assignment folder includes:

- Python source code.
- README.md documentation.
- requirements.txt file.
- Execution screenshots and reports wherever applicable.

## Purpose of This Repository

This repository represents my practical learning journey in Python Backend Development.

It demonstrates the implementation of backend programming concepts through practical assignments and helps showcase my technical skills, problem-solving approach, and understanding of backend application development.

**Author:** Python Backend Development Trainee

**Repository:** Python Backend Development Assessments